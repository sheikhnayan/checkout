<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Website;
use App\Models\Addon;
use App\Models\Event;
use App\Models\PromoCode;

class FrontendController extends Controller
{
    public function index(Request $request)
    {
        // Logic for the index method

        $data = Website::where('domain', $request->domain)->first();

        if (isset($request->event_name)) {
            # code...
            $event = Event::where('name', $request->event_name)->first();
            return view('index', compact('data', 'event')); // Assuming 'index' is the view you want to return
        }

        return view('index_two', compact('data')); // Assuming 'index' is the view you want to return

        // dd($event);

    }

    public function addons($id)
    {
        $data = Addon::where('package_id', $id)->get();

        return response()->json($data);
    }

    public function checkCode($code)
    {
        $check = PromoCode::where('promo_code', $code)->first();

        if ($check) {
            return response()->json(['valid' => true, 'discount' => $check->percentage, 'type' => $check->type, 'id' => $check->id]);
        }

        return response()->json(['valid' => false]);
    }
}
