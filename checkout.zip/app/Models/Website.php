<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Website extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'domain',
        'logo',
        'logo_width',
        'logo_height',
        'guest_list_button_text',
        'package_button_text',
        'transportation_confirmation_text',
        'visa_logo',
        'mastercard_logo',
        'amex_logo',
        'google_pay_logo',
        'apple_pay_logo',
        'refundable_fee',
        'gratuity_fee',
        'font_color',
        'text_description',
        'description_label',
        'status',
        'is_archieved',
    ];

    /**
     * Get the packages for the website.
     */
    public function packages()
    {
        return $this->hasMany(Package::class);
    }

    public function events()
    {
        return $this->hasMany(Event::class);
    }

    public function emails()
    {
        return $this->hasMany(Email::class, 'website_id', 'id');
    }

    public function smtp()
    {
        return $this->hasOne(SMTP::class, 'website_id', 'id');
    }

    public function paymentLogos()
    {
        return $this->hasMany(PaymentLogo::class)->where('is_active', true)->orderBy('order');
    }
}
